# Fullstack Web Application

A lightweight full-stack starter application featuring an Express backend API and a vanilla HTML/CSS/JS frontend.

## Project Structure

```text
my-project/
├── backend/
│   ├── package.json
│   └── server.js
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── .gitignore
└── README.md